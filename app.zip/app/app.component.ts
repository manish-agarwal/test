import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  ques1="What is your pet name?";
  ques2="What is the make of your first vehicle?";

  constructor() { 
    
  }

  ngOnInit() {

  }

}
