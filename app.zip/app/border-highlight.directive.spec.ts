/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { BorderHighlightDirective } from './border-highlight.directive';

describe('BorderHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new BorderHighlightDirective();
    expect(directive).toBeTruthy();
  });
});
